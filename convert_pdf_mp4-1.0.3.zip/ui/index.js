/**
 * PDF解说视频生成器 —— QwenPaw 前端入口
 * 进应用 = 先请求 PawApp 后端 /api/convert_pdf_mp4/api/service 拿到托管 Flask 服务的
 * 实际 URL（SDK 自动分配端口），再 iframe 打开；服务未就绪时显示“启动中”并自动重试。
 * 三段注册同 shougonghua/chineselottery：registerRoutes(/apps) + menu.add + route.add。
 */
(function () {
  'use strict';

  if (!window.QwenPaw || !window.QwenPaw.host) {
    console.error('[convert_pdf_mp4] QwenPaw host not ready');
    return;
  }

  var QP = window.QwenPaw;
  var React = QP.host.React;
  var h = React.createElement;
  var PLUGIN_ID = 'convert_pdf_mp4';
  var SERVICE_API = '/plugins/convert_pdf_mp4/api/service';
  var PAGE_URL = '/plugins/convert_pdf_mp4/proxy/';

  function apiUrl(p) {
    try {
      if (QP.host.getApiUrl) { return QP.host.getApiUrl(p); }
    } catch (e) { /* 走兜底 */ }
    return '/api' + p;
  }

  function pageURL() {
    return window.location.origin + apiUrl(PAGE_URL);
  }

  function PdfVideoPage() {
    var _s = React.useState(null);
    var service = _s[0], setService = _s[1];
    var _l = React.useState('loading');
    var state = _l[0], setState = _l[1];
    var _r = React.useState(0);
    var retryKey = _r[0], setRetryKey = _r[1];

    React.useEffect(function () {
      var cancelled = false;
      var timer = null;
      function load() {
        setState('loading');
        fetch(apiUrl(SERVICE_API))
          .then(function (resp) { return resp.json(); })
          .then(function (data) {
            if (cancelled) return;
            if (data && data.ready && data.url) {
              setService(data.url);
              setState('ready');
            } else {
              setState('starting');
              timer = setTimeout(load, 1500);
            }
          })
          .catch(function () {
            if (cancelled) return;
            setState('error');
          });
      }
      load();
      return function () {
        cancelled = true;
        if (timer) clearTimeout(timer);
      };
    }, [retryKey]);

    var content;
    if (state === 'ready' && service) {
      content = h('iframe', {
        key: 'pdfvideo-' + retryKey,
        src: pageURL(),
        title: 'PDF解说视频生成器',
        style: {
          flex: '1 1 auto', width: '100%', minHeight: 580,
          border: 'none', display: 'block',
        },
      });
    } else {
      content = h('div', {
        style: {
          flex: '1 1 auto', display: 'flex', alignItems: 'center', justifyContent: 'center',
          minHeight: 580, background: '#f7f7f8', color: '#666', fontSize: 14,
        },
      },
        state === 'error'
          ? h('div', { style: { textAlign: 'center' } },
              h('p', {}, '无法获取服务状态，请重试'),
              h('button', {
                style: { marginTop: 8, padding: '6px 16px', cursor: 'pointer' },
                onClick: function () { setRetryKey(function (k) { return k + 1; }); },
              }, '重试'))
          : h('div', { style: { textAlign: 'center' } },
              h('p', {}, 'PDF视频生成器服务启动中，首次加载需数秒…'),
              h('p', { style: { fontSize: 12, color: '#999', marginTop: 6 } }, '正在拉起 Flask 视频生成服务'))
      );
    }

    return h('div', {
      style: {
        position: 'relative', width: '100%', height: '100%', minHeight: 620,
        background: '#f7f7f8', display: 'flex', flexDirection: 'column',
        fontFamily: '"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif',
      },
    }, content);
  }

  // ── 1. 应用栏目（路径与 plugin.json 的 pawapp.entry_page 一致）──
  if (QP.registerRoutes) {
    try {
      QP.registerRoutes(PLUGIN_ID, [{
        path: '/apps/' + PLUGIN_ID,
        component: PdfVideoPage,
        label: 'PDF解说视频生成器',
        icon: '🎬',
      }]);
      console.info('[' + PLUGIN_ID + '] registered via registerRoutes');
    } catch (e) { console.warn('[' + PLUGIN_ID + '] registerRoutes failed:', e); }
  }

  // ── 2. 侧边栏菜单 ──
  if (QP.menu && QP.menu.add) {
    try {
      QP.menu.add(PLUGIN_ID, [{
        id: PLUGIN_ID + '.menu',
        location: 'primary.settings',
        label: 'PDF解说视频生成器',
        icon: function () {
          return h('span', { style: { fontSize: 15, fontWeight: 700 } }, '🎬');
        },
        route: PLUGIN_ID + '.home',
        order: 71,
      }]);
      console.info('[' + PLUGIN_ID + '] registered via menu.add');
    } catch (e) { console.warn('[' + PLUGIN_ID + '] menu.add failed:', e); }
  }

  // ── 3. 侧边栏路由 ──
  if (QP.route && QP.route.add) {
    try {
      QP.route.add(PLUGIN_ID, [{
        id: PLUGIN_ID + '.home',
        path: '/plugin/' + PLUGIN_ID,
        component: PdfVideoPage,
      }]);
      console.info('[' + PLUGIN_ID + '] registered via route.add');
    } catch (e) { console.warn('[' + PLUGIN_ID + '] route.add failed:', e); }
  }
})();