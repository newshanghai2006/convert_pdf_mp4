# -*- coding: utf-8 -*-
"""
PDF解说视频生成器 (convert_pdf_mp4) PawApp 后端

结构（PluginApi 模式，与 shougonghua/chineselottery 同款，路由挂 /api/plugins/convert_pdf_mp4）：
- 通过 startup hook 在插件加载时拉起原 Flask 服务（app.py --port 5006）作为独立子进程；
  进程健康探活 /，就绪后前端可用。
- 通过 /proxy/{path} 把 Flask 服务的全部请求（页面、上传、任务、下载）以宿主同源方式
  反向代理出去：前端 iframe 打开 /api/plugins/convert_pdf_mp4/proxy/，不跨端口、不跨域，
  浏览器沙箱/外网场景均可用。上传 PDF 与下载 MP4 也走该代理。
"""
from __future__ import annotations

import asyncio
import logging
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

import httpx
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, Response

PLUGIN_ID = "convert_pdf_mp4"
PLUGIN_NAME = "PDF解说视频生成器"
VERSION = "1.0.0"
SERVICE_PORT = int(os.environ.get("CONVERT_PDF_MP4_PORT", "5006"))
SERVICE_URL = f"http://127.0.0.1:{SERVICE_PORT}"

APP_DIR = Path(__file__).resolve().parent / "app"

logger = logging.getLogger("qwenpaw").getChild("plugin.convert_pdf_mp4")

router = APIRouter()

_proc: subprocess.Popen | None = None
_proxy_client: httpx.AsyncClient | None = None

# 逐跳头不需要转发给后端
_HOP_HEADERS = {
    "host", "content-length", "connection", "keep-alive",
    "transfer-encoding", "upgrade", "proxy-authorization",
    "proxy-connection",
}

# Flask 前端硬编码绝对路径（/api/...、/static/...）。iframe 打开同源代理页时，
# 这些路径会打到 QwenPaw 宿主根，因此需要在 HTML/JS/CSS 响应里把它们前缀化到本代理。
_PROXY_PREFIX = f"/api/plugins/{PLUGIN_ID}/proxy"
_TEXT_REWRITES = [
    ("'/api/", f"'{_PROXY_PREFIX}/api/"),
    ('"/api/', f'"{_PROXY_PREFIX}/api/'),
    ("'/static/", f"'{_PROXY_PREFIX}/static/"),
    ('"/static/', f'"{_PROXY_PREFIX}/static/'),
]


def _rewrite_text_content(content: bytes, content_type: str) -> bytes:
    ctype = content_type.split(";")[0].strip().lower()
    if ctype not in {
        "text/html", "application/javascript", "text/javascript",
        "text/css", "application/xhtml+xml",
    }:
        return content
    text = content.decode("utf-8", errors="replace")
    for old, new in _TEXT_REWRITES:
        text = text.replace(old, new)
    return text.encode("utf-8")


def _health_ok() -> bool:
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(f"{SERVICE_URL}/", timeout=2) as resp:
            return 200 <= resp.status < 400
    except Exception:  # noqa: BLE001
        return False


async def _ensure_service() -> None:
    """确保 Flask 服务进程在运行，等待就绪（最多 120s）。"""
    global _proc
    if _health_ok():
        return
    if _proc is None or _proc.poll() is not None:
        out = open(APP_DIR / "plugin_service.log", "ab")
        _proc = subprocess.Popen(
            [sys.executable, "app.py", "--port", str(SERVICE_PORT)],
            cwd=str(APP_DIR),
            stdout=out,
            stderr=out,
        )
        logger.info("convert_pdf_mp4 service started pid=%s port=%s", _proc.pid, SERVICE_PORT)
    deadline = time.monotonic() + 120
    while time.monotonic() < deadline:
        if _proc.poll() is not None:
            logger.error("convert_pdf_mp4 service exited code=%s", _proc.returncode)
            break
        if _health_ok():
            logger.info("convert_pdf_mp4 service healthy at %s", SERVICE_URL)
            return
        await asyncio.sleep(0.5)


async def _stop_service() -> None:
    global _proc, _proxy_client
    if _proc is not None and _proc.poll() is None:
        _proc.terminate()
        try:
            await asyncio.wait_for(asyncio.to_thread(_proc.wait), 10)
        except asyncio.TimeoutError:
            _proc.kill()
            await asyncio.to_thread(_proc.wait)
    _proc = None
    if _proxy_client is not None:
        await _proxy_client.aclose()
        _proxy_client = None


async def _get_proxy_client() -> httpx.AsyncClient:
    global _proxy_client
    if _proxy_client is None:
        _proxy_client = httpx.AsyncClient(
            base_url=SERVICE_URL,
            timeout=httpx.Timeout(7200.0, connect=10.0),
        )
    return _proxy_client


# -------------------------- HTTP 路由 ---------------------------
@router.get("/health")
async def health():
    return {"status": "ok", "id": PLUGIN_ID, "name": PLUGIN_NAME, "version": VERSION}


@router.get("/api/service")
async def service_info():
    """返回托管服务当前状态与实际访问 URL（诊断用）。"""
    return JSONResponse({
        "ok": True,
        "ready": _health_ok(),
        "url": SERVICE_URL,
        "name": PLUGIN_NAME,
    })


@router.api_route("/proxy/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"])
async def proxy(path: str, request: Request):
    """通用反向代理：把前端同源请求转发到 Flask 服务。"""
    client = await _get_proxy_client()
    body = await request.body()
    headers = {
        k: v
        for k, v in request.headers.items()
        if k.lower() not in _HOP_HEADERS
    }
    url = "/" + path
    if request.url.query:
        url += "?" + request.url.query
    upstream = await client.request(
        request.method,
        url,
        content=body or None,
        headers=headers,
    )
    # Flask 应用设置了 CSP frame-ancestors 'none'（防嵌入），经代理嵌入时剥掉
    # 相关安全头，否则 iframe 会被浏览器拒绝。
    resp_headers = {
        k: v
        for k, v in upstream.headers.items()
        if k.lower() not in {
            "content-length", "connection", "transfer-encoding",
            "content-security-policy", "x-frame-options",
        }
    }
    ctype = upstream.headers.get("content-type", "")
    content = _rewrite_text_content(upstream.content, ctype)
    if content is not upstream.content:
        resp_headers["content-length"] = str(len(content))
    return Response(
        content=content,
        status_code=upstream.status_code,
        headers=resp_headers,
    )


class ConvertPdfPlugin:
    """QwenPaw 2.0 PluginApi 标准入口"""

    id = PLUGIN_ID
    name = PLUGIN_NAME
    version = VERSION

    def __init__(self):
        self.router = router

    def register(self, api) -> None:
        api.register_http_router(
            router,
            prefix="/plugins/" + PLUGIN_ID,
            tags=[PLUGIN_ID],
        )
        api.register_startup_hook(
            hook_name="convert_pdf_mp4_service_start",
            callback=_ensure_service,
            priority=70,
        )
        api.register_shutdown_hook(
            hook_name="convert_pdf_mp4_service_stop",
            callback=_stop_service,
            priority=130,
        )
        print("[PDF解说视频生成器] backend registered")


plugin = ConvertPdfPlugin()